#ifndef TCP_H
#define TCP_H

#include <QWidget>
#include <QTcpSocket>
#include <QMessageBox>
#include <QTimer>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QGroupBox>
#include <QTimer>
#include <QDateTime>
#include <QJsonDocument>
#include <QJsonObject>

class tcp : public QWidget
{
    Q_OBJECT

public:
    explicit tcp(QWidget *parent = nullptr);
    ~tcp();

private slots:
    void onConnectClicked();
    void onDisconnectClicked();
    void socketConnected();
    void socketDisconnected();
    void socketReadyRead();
    void socketError(QAbstractSocket::SocketError error);
    void reconnect();

private:
    void createUI();
    void setupConnections();
    void updateUI(bool connected);

    QTcpSocket *tcpSocket;
    QTimer *reconnectTimer;
    QString serverAddress;
    quint16 serverPort;

    // UI 元素
    QLineEdit *serverAddressEdit;
    QLineEdit *serverPortEdit;
    QPushButton *connectButton;
    QPushButton *disconnectButton;
    QLabel *statusLabel;

    // 传感器数据显示
    QLabel *tempLabel;
    QLabel *humiLabel;
    QLabel *concLabel;

    // RFID数据显示
    QLabel *rfidLabel;
    QLabel *actionLabel;
    QLabel *timeLabel;

    // 数据接收显示
    QTextEdit *receivedDataEdit;
};

#endif // TCP_H
