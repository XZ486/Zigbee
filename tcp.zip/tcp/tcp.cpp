#include "tcp.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QMessageBox>
#include <QDateTime>

tcp::tcp(QWidget *parent) :
    QWidget(parent),
    tcpSocket(new QTcpSocket(this)),
    reconnectTimer(new QTimer(this)),
    serverAddress("192.168.216.47"),
    serverPort(8080)
{
    createUI();
    setupConnections();
    updateUI(false);
}

tcp::~tcp()
{
    if(tcpSocket->state() == QAbstractSocket::ConnectedState) {
        tcpSocket->disconnectFromHost();
    }
}

void tcp::createUI()
{
    // 主布局
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(10);
    mainLayout->setContentsMargins(10, 10, 10, 10);

    // 连接设置区域
    QGroupBox *connectionGroup = new QGroupBox("连接设置", this);
    QHBoxLayout *connectionLayout = new QHBoxLayout(connectionGroup);
    connectionLayout->setSpacing(10);

    serverAddressEdit = new QLineEdit(serverAddress, this);
    serverPortEdit = new QLineEdit(QString::number(serverPort), this);
    connectButton = new QPushButton("连接", this);
    disconnectButton = new QPushButton("断开", this);

    connectionLayout->addWidget(new QLabel("服务器地址:", this));
    connectionLayout->addWidget(serverAddressEdit);
    connectionLayout->addWidget(new QLabel("端口:", this));
    connectionLayout->addWidget(serverPortEdit);
    connectionLayout->addWidget(connectButton);
    connectionLayout->addWidget(disconnectButton);

    // 状态显示
    statusLabel = new QLabel("未连接", this);
    statusLabel->setAlignment(Qt::AlignCenter);
    statusLabel->setStyleSheet("font-weight: bold; font-size: 14px;");

    // 数据展示区域
    QHBoxLayout *dataDisplayLayout = new QHBoxLayout();
    dataDisplayLayout->setSpacing(15);

    // 传感器数据区域
    QGroupBox *sensorGroup = new QGroupBox("传感器数据", this);
    QGridLayout *sensorLayout = new QGridLayout(sensorGroup);
    sensorLayout->setSpacing(10);

    tempLabel = new QLabel("温度: -- °C", sensorGroup);
    tempLabel->setStyleSheet("font-weight: bold; color: blue; font-size: 13px;");
    humiLabel = new QLabel("湿度: -- %", sensorGroup);
    humiLabel->setStyleSheet("font-weight: bold; color: green; font-size: 13px;");
    concLabel = new QLabel("浓度: -- ppm", sensorGroup);
    concLabel->setStyleSheet("font-weight: bold; color: purple; font-size: 13px;");

    sensorLayout->addWidget(tempLabel, 0, 0);
    sensorLayout->addWidget(humiLabel, 0, 1);
    sensorLayout->addWidget(concLabel, 1, 0);

    // RFID数据区域
    QGroupBox *rfidGroup = new QGroupBox("RFID数据", this);
    QVBoxLayout *rfidLayout = new QVBoxLayout(rfidGroup);
    rfidLayout->setSpacing(10);

    rfidLabel = new QLabel("RFID标签: --", rfidGroup);
    rfidLabel->setStyleSheet("font-weight: bold; font-size: 13px;");
    actionLabel = new QLabel("操作类型: --", rfidGroup);
    actionLabel->setStyleSheet("font-weight: bold; color: red; font-size: 13px;");
    timeLabel = new QLabel("检测时间: --", rfidGroup);
    timeLabel->setStyleSheet("font-style: italic; font-size: 12px;");

    rfidLayout->addWidget(rfidLabel);
    rfidLayout->addWidget(actionLabel);
    rfidLayout->addWidget(timeLabel);

    dataDisplayLayout->addWidget(sensorGroup);
    dataDisplayLayout->addWidget(rfidGroup);

    // 接收数据显示区域
    receivedDataEdit = new QTextEdit(this);
    receivedDataEdit->setReadOnly(true);
    receivedDataEdit->setPlaceholderText("接收到的数据将显示在这里...");

    // 添加到主布局
    mainLayout->addWidget(connectionGroup);
    mainLayout->addWidget(statusLabel);
    mainLayout->addLayout(dataDisplayLayout);
    mainLayout->addWidget(receivedDataEdit);

    this->setMinimumSize(700, 500);
    this->setWindowTitle("基于物联网的种子仓库监管系统--肖泽毕业设计");
    this->setWindowIcon(QIcon(":/icons/app_icon.png"));
}

void tcp::setupConnections()
{
    connect(connectButton, &QPushButton::clicked, this, &tcp::onConnectClicked);
    connect(disconnectButton, &QPushButton::clicked, this, &tcp::onDisconnectClicked);

    connect(tcpSocket, &QTcpSocket::connected, this, &tcp::socketConnected);
    connect(tcpSocket, &QTcpSocket::disconnected, this, &tcp::socketDisconnected);
    connect(tcpSocket, &QTcpSocket::readyRead, this, &tcp::socketReadyRead);
    connect(tcpSocket, QOverload<QAbstractSocket::SocketError>::of(&QTcpSocket::error),
            this, &tcp::socketError);

    reconnectTimer->setInterval(5000);
    connect(reconnectTimer, &QTimer::timeout, this, &tcp::reconnect);
}

void tcp::updateUI(bool connected)
{
    connectButton->setEnabled(!connected);
    disconnectButton->setEnabled(connected);
    serverAddressEdit->setEnabled(!connected);
    serverPortEdit->setEnabled(!connected);

    if(connected) {
        statusLabel->setText("已连接到ESP8266");
        statusLabel->setStyleSheet("color: green; font-weight: bold; font-size: 14px;");
    } else {
        statusLabel->setText("未连接");
        statusLabel->setStyleSheet("color: red; font-weight: bold; font-size: 14px;");
    }
}

void tcp::onConnectClicked()
{
    serverAddress = serverAddressEdit->text().trimmed();
    serverPort = serverPortEdit->text().toUShort();

    if(serverAddress.isEmpty()) {
        QMessageBox::warning(this, "错误", "服务器地址不能为空");
        return;
    }

    // 先断开已有连接
    if(tcpSocket->state() != QAbstractSocket::UnconnectedState) {
        tcpSocket->disconnectFromHost();
        if(tcpSocket->state() != QAbstractSocket::UnconnectedState) {
            tcpSocket->waitForDisconnected(1000);
        }
    }

    statusLabel->setText("正在连接...");
    statusLabel->setStyleSheet("color: blue; font-weight: bold; font-size: 14px;");

    tcpSocket->connectToHost(serverAddress, serverPort);

    // 添加连接超时检查
    if(!tcpSocket->waitForConnected(3000)) {
        statusLabel->setText("连接超时");
        statusLabel->setStyleSheet("color: red; font-weight: bold; font-size: 14px;");
        receivedDataEdit->append("连接服务器超时，请检查网络和服务器状态");
    }
}

void tcp::onDisconnectClicked()
{
    tcpSocket->disconnectFromHost();
    reconnectTimer->stop();
}

void tcp::socketConnected()
{
    updateUI(true);
    reconnectTimer->stop();
    receivedDataEdit->append("<font color='green'>已连接到ESP8266服务器</font>");
}

void tcp::socketDisconnected()
{
    updateUI(false);
    receivedDataEdit->append("<font color='orange'>与服务器断开连接</font>");

    if(!reconnectTimer->isActive() && connectButton->isEnabled()) {
        reconnectTimer->start();
    }
}

void tcp::socketReadyRead()
{
    while(tcpSocket->bytesAvailable()) {
        QString line = QString::fromUtf8(tcpSocket->readLine()).trimmed();

        // 在接收框中显示原始数据
        receivedDataEdit->append("原始数据: " + line);

        // 尝试解析JSON格式数据
        if(line.startsWith("{") && line.endsWith("}")) {
            QJsonParseError error;
            QJsonDocument doc = QJsonDocument::fromJson(line.toUtf8(), &error);

            if(error.error == QJsonParseError::NoError && !doc.isNull()) {
                QJsonObject obj = doc.object();

                // 处理传感器数据
                if(obj.contains("temp") || obj.contains("humi") || obj.contains("conc")) {
                    if(obj.contains("temp")) {
                        double temp = obj["temp"].toDouble();
                        tempLabel->setText(QString("温度: %1 °C").arg(temp, 0, 'f', 1));
                    }
                    if(obj.contains("humi")) {
                        double humi = obj["humi"].toDouble();
                        humiLabel->setText(QString("湿度: %1 %").arg(humi, 0, 'f', 1));
                    }
                    if(obj.contains("conc")) {
                        int conc = obj["conc"].toInt();
                        concLabel->setText(QString("浓度: %1 ppm").arg(conc));
                    }
                    receivedDataEdit->append("<font color='green'>成功解析传感器数据</font>");
                }

                // 处理RFID数据
                if(obj.contains("rfid")) {
                    QString rfid = obj["rfid"].toString();
                    rfidLabel->setText("RFID标签: " + rfid);

                    QString action;
                    if(rfid == "E600B701") {
                        action = "入库";
                    } else if(rfid == "C5AA3F02") {
                        action = "出库";
                    } else {
                        action = "未知操作";
                    }

                    actionLabel->setText("操作类型: " + action);
                    timeLabel->setText("检测时间: " + QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));

                    receivedDataEdit->append(QString("<font color='red'>RFID操作: %1 (标签: %2)</font>").arg(action).arg(rfid));
                }
            } else {
                receivedDataEdit->append("<font color='orange'>JSON解析错误: " + error.errorString() + "</font>");
            }
        }
        // 解析原始文本格式数据
        else {
            // 处理传感器数据
            if(line.startsWith("Temperature:")) {
                QString tempValue = line.mid(12);
                tempLabel->setText("温度: " + tempValue + " °C");
                receivedDataEdit->append("<font color='green'>更新温度数据</font>");
            }
            else if(line.startsWith("Humidity:")) {
                QString humiValue = line.mid(9);
                humiLabel->setText("湿度: " + humiValue + " %");
                receivedDataEdit->append("<font color='green'>更新湿度数据</font>");
            }
            else if(line.startsWith("Concentration:")) {
                QString concValue = line.mid(14);
                concLabel->setText("浓度: " + concValue + " ppm");
                receivedDataEdit->append("<font color='green'>更新浓度数据</font>");
            }
            // 处理RFID数据
            else if(line.startsWith("RFID:")) {
                QString rfid = line.mid(5);
                rfidLabel->setText("RFID标签: " + rfid);

                QString action;
                if(rfid == "E600B701") {
                    action = "入库";
                } else if(rfid == "C5AA3F02") {
                    action = "出库";
                } else {
                    action = "未知操作";
                }

                actionLabel->setText("操作类型: " + action);
                timeLabel->setText("检测时间: " + QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));

                receivedDataEdit->append(QString("<font color='red'>RFID操作: %1 (标签: %2)</font>").arg(action).arg(rfid));
            }
        }
    }
}

void tcp::socketError(QAbstractSocket::SocketError error)
{
    Q_UNUSED(error);

    QString errorMsg = tcpSocket->errorString();
    statusLabel->setText("错误: " + errorMsg);
    statusLabel->setStyleSheet("color: red; font-weight: bold; font-size: 14px;");
    receivedDataEdit->append("<font color='red'>错误: " + errorMsg + "</font>");

    if(!reconnectTimer->isActive() && connectButton->isEnabled()) {
        reconnectTimer->start();
    }
}

void tcp::reconnect()
{
    statusLabel->setText("尝试重新连接...");
    statusLabel->setStyleSheet("color: blue; font-weight: bold; font-size: 14px;");
    receivedDataEdit->append("<font color='blue'>尝试重新连接服务器...</font>");
    tcpSocket->connectToHost(serverAddress, serverPort);
}
