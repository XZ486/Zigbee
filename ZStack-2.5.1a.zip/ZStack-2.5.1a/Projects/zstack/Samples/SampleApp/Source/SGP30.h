#ifndef SGP30_H
#define SGP30_H

#include "public.h"

#define ADDR_WRITE 0xB0
#define ADDR_READ 0xB1

#define ACK 0
#define NACK 1

#define SDA_PIN P1_2
#define SCL_PIN P1_3
#define SDA_OUT_HIGH SDA_PIN = 1
#define SCL_OUT_HIGH SCL_PIN = 1
#define SDA_OUT_LOW SDA_PIN = 0
#define SCL_OUT_LOW SCL_PIN = 0

void I2C_Init();
void I2C_Start();
void I2c_Stop();
void I2C_Delay_us(int i);
void I2C_Delay_ms(int time);
uint8_t I2C_SendByte(unsigned char data);
void I2C_SendACK(uint8_t ack);
uint8_t I2C_ReadByte(uint8_t ack);
unsigned long SGP30_Read();
void SGP30_Init();
void SGP30_Write();

#endif