/*********************************************************************
 * INCLUDES
 */
#include <iocc2530.h>
#include <stdio.h>
#include <string.h>
#include "AF.h"
#include "OnBoard.h"
#include "OSAL_Tasks.h"
#include "SampleApp.h"
#include "ZDApp.h"
#include "ZDObject.h"
#include "ZDProfile.h"

#include "hal_drivers.h"
#include "hal_key.h"
#if defined ( LCD_SUPPORTED )
  #include "hal_lcd.h"
#endif
#include "hal_led.h"
#include "hal_uart.h"
#include "dht11.h"
#include "SGP30.h"
#include "UART.h"
#include "mfrc522.h"

/*********************************************************************
 * MACROS
 */
#define ACTUATOR_PIN P1_0

//M1����ĳһ��дΪ���¸�ʽ����ÿ�ΪǮ�����ɽ��տۿ�ͳ�ֵ����
//4�ֽڽ����ֽ���ǰ����4�ֽڽ��ȡ����4�ֽڽ�1�ֽڿ��ַ��1
//�ֽڿ��ַȡ����1�ֽڿ��ַ��1�ֽڿ��ַȡ�� 
unsigned char DefaultKey[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}; 
unsigned char g_ucTempbuf[20];    
unsigned char MLastSelectedSnr[4];
unsigned char RevBuffer[30];  
unsigned char SerBuffer[20]; 
unsigned char CmdValid; 

/*********************************************************************
 * CONSTANTS
 */

#if !defined( SAMPLE_APP_PORT )
#define SAMPLE_APP_PORT  0
#endif

#if !defined( SAMPLE_APP_BAUD )
  #define SAMPLE_APP_BAUD  HAL_UART_BR_115200
#endif

// When the Rx buf space is less than this threshold, invoke the Rx callback.
#if !defined( SAMPLE_APP_THRESH )
#define SAMPLE_APP_THRESH  64
#endif

#if !defined( SAMPLE_APP_RX_SZ )
#define SAMPLE_APP_RX_SZ  128
#endif

#if !defined( SAMPLE_APP_TX_SZ )
#define SAMPLE_APP_TX_SZ  128
#endif

// Millisecs of idle time after a byte is received before invoking Rx callback.
#if !defined( SAMPLE_APP_IDLE )
#define SAMPLE_APP_IDLE  6
#endif

// Loopback Rx bytes to Tx for throughput testing.
#if !defined( SAMPLE_APP_LOOPBACK )
#define SAMPLE_APP_LOOPBACK  FALSE
#endif

// This is the max byte count per OTA message.
#if !defined( SAMPLE_APP_TX_MAX )
#define SAMPLE_APP_TX_MAX  80
#endif

#define SAMPLE_APP_RSP_CNT  4

// This list should be filled with Application specific Cluster IDs.
const cId_t SampleApp_ClusterList[SAMPLE_MAX_CLUSTERS] =
{
  SAMPLEAPP_P2P_CLUSTERID,
  SAMPLEAPP_P2P_CLUSTERID1,
};

const SimpleDescriptionFormat_t SampleApp_SimpleDesc =
{
  SAMPLEAPP_ENDPOINT,              //  int   Endpoint;
  SAMPLEAPP_PROFID,                //  uint16 AppProfId[2];
  SAMPLEAPP_DEVICEID,              //  uint16 AppDeviceId[2];
  SAMPLEAPP_DEVICE_VERSION,        //  int   AppDevVer:4;
  SAMPLEAPP_FLAGS,                 //  int   AppFlags:4;
  SAMPLE_MAX_CLUSTERS,          //  byte  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList,  //  byte *pAppInClusterList;
  SAMPLE_MAX_CLUSTERS,          //  byte  AppNumOutClusters;
  (cId_t *)SampleApp_ClusterList   //  byte *pAppOutClusterList;
};

endPointDesc_t SampleApp_epDesc =
{
  SAMPLEAPP_ENDPOINT,
 &SampleApp_TaskID,
  (SimpleDescriptionFormat_t *)&SampleApp_SimpleDesc,
  noLatencyReqs
};

/*********************************************************************
 * TYPEDEFS
 */
//#define SENSOR_TERMINAL
//#define ACTUATOR_TERMINAL
/*********************************************************************
 * GLOBAL VARIABLES
 */
devStates_t SampleApp_NwkState;   
uint8 SampleApp_TaskID;           // Task ID for internal task/event processing.
uint8 temp1Int;//Э���������ն�1�¶�
uint8 hum1Int;//Э���������ն�1ʪ��
unsigned long co2Int;
int flag = 0;

/*********************************************************************
 * EXTERNAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL FUNCTIONS
 */

/*********************************************************************
 * LOCAL VARIABLES
 */

static uint8 SampleApp_MsgID;

afAddrType_t SampleApp_Periodic_DstAddr; //�㲥
afAddrType_t SampleApp_Flash_DstAddr;    //�鲥
afAddrType_t SampleApp_P2P_DstAddr;      //�㲥

static afAddrType_t SampleApp_TxAddr;
static uint8 SampleApp_TxSeq;
static uint8 SampleApp_TxBuf[SAMPLE_APP_TX_MAX+1];
static uint8 SampleApp_TxLen;

static afAddrType_t SampleApp_RxAddr;
static uint8 SampleApp_RxSeq;
static uint8 SampleApp_RspBuf[SAMPLE_APP_RSP_CNT];
static uint16 devAddr[3] = {0};
/*********************************************************************
 * LOCAL FUNCTIONS
 */

static void SampleApp_ProcessMSGCmd( afIncomingMSGPacket_t *pkt );
void SampleApp_CallBack(uint8 port, uint8 event); 
static void SampleApp_Send_P2P_Message( void );
static void RFID_Init();
static void SampleApp_SendPeriodicMessage( void );
static void iccardcode();

/*********************************************************************
 * @fn      SampleApp_Init
 *
 * @brief   This is called during OSAL tasks' initialization.
 *
 * @param   task_id - the Task ID assigned by OSAL.
 *
 * @return  none
 */
void SampleApp_Init( uint8 task_id )
{
  halUARTCfg_t uartConfig;

  SampleApp_TaskID = task_id;
  SampleApp_RxSeq = 0xC3;
  SampleApp_NwkState = DEV_INIT;       

  MT_UartInit();                  //���ڳ�ʼ��
  MT_UartRegisterTaskID(task_id); //ע�ᴮ������
  afRegister( (endPointDesc_t *)&SampleApp_epDesc );
  RegisterForKeys( task_id );

#ifdef ZDO_COORDINATOR
  //Э������ʼ��
  
  //���������ʼ��

  P0SEL &= ~0x80;                 //����P07Ϊ��ͨIO��
  P0DIR |= 0x80;                 //P07����Ϊ�����

  //Ĭ�Ϸ���������
  P0_7 = 0;
#elif defined ( SENSOR_TERMINAL )
  I2C_Init();
  SGP30_Init();
  RFID_Init();
  
#endif

  SampleApp_Periodic_DstAddr.addrMode = (afAddrMode_t)AddrBroadcast;//�㲥
  SampleApp_Periodic_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Periodic_DstAddr.addr.shortAddr = 0xFFFF;

  // Setup for the flash command's destination address - Group 1
  SampleApp_Flash_DstAddr.addrMode = (afAddrMode_t)afAddrGroup;//�鲥
  SampleApp_Flash_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Flash_DstAddr.addr.shortAddr = SAMPLEAPP_FLASH_GROUP;
  
  SampleApp_P2P_DstAddr.addrMode = (afAddrMode_t)Addr16Bit; //�㲥 
  SampleApp_P2P_DstAddr.endPoint = SAMPLEAPP_ENDPOINT; 
  SampleApp_P2P_DstAddr.addr.shortAddr = 0x0000;            //����Э����

  
}

//BCDתASC���
char NumberToLetter(unsigned char number)
{
    char buff[]="0123456789ABCDEF";

    if(number>15) return 0;

    return buff[number];

}

/*********************************************************************
 * @fn      SampleApp_ProcessEvent
 *
 * @brief   Generic Application Task event processor.
 *
 * @param   task_id  - The OSAL assigned task ID.
 * @param   events   - Bit map of events to process.
 *
 * @return  Event flags of all unprocessed events.
 */
UINT16 SampleApp_ProcessEvent( uint8 task_id, UINT16 events )
{
  (void)task_id;  // Intentionally unreferenced parameter
  
  if ( events & SYS_EVENT_MSG )
  {
    afIncomingMSGPacket_t *MSGpkt;

    while ( (MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID )) )
    {
      switch ( MSGpkt->hdr.event )
      {
      case AF_INCOMING_MSG_CMD:
        SampleApp_ProcessMSGCmd( MSGpkt );
        break;
        
      case ZDO_STATE_CHANGE:
        SampleApp_NwkState = (devStates_t)(MSGpkt->hdr.status);
        if ( (SampleApp_NwkState == DEV_ZB_COORD)||
            (SampleApp_NwkState == DEV_ROUTER)
            || (SampleApp_NwkState == DEV_END_DEVICE) )
        {
            //�����ɹ�������һ����ʱ��
#if defined ( ZDO_COORDINATOR )
          
#else
            SampleApp_DeviceConnect();
#endif
            osal_start_timerEx( SampleApp_TaskID,
                                SAMPLEAPP_SEND_PERIODIC_MSG_EVT,
                                SAMPLEAPP_SEND_PERIODIC_MSG_TIMEOUT );
            
            osal_start_timerEx( SampleApp_TaskID, 
                                SAMPLEAPP_SEND_PERIODIC_MSG_EVT1, 
                                500);
        }
        else
        {
          // Device is no longer in the network
        }
        break;

      default:
        break;
      }

      osal_msg_deallocate( (uint8 *)MSGpkt );
    }

    return ( events ^ SYS_EVENT_MSG );
  }

  //��ʱ��ʱ�䵽
  if ( events & SAMPLEAPP_SEND_PERIODIC_MSG_EVT )
  {
#if defined ( ZDO_COORDINATOR )
    //Э���������������
    uint8 buff[100]={0};
    //��ʽ���¶����ݣ����ڴ������
    sprintf(buff, "Temperature:%d Humidity:%d Concentration:%lu\r\n", temp1Int, hum1Int, co2Int);
    //���������ʾ��Ϣ
    HalUARTWrite(0, buff, osal_strlen(buff));           
#elif defined ( SENSOR_TERMINAL )   
    //�ն����ڲɼ���ʪ������
    SampleApp_Send_P2P_Message();
#endif

    // ����������ʱ��
    osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SEND_PERIODIC_MSG_EVT,
        (SAMPLEAPP_SEND_PERIODIC_MSG_TIMEOUT + (osal_rand() & 0x00FF)) );

    // return unprocessed events
    return (events ^ SAMPLEAPP_SEND_PERIODIC_MSG_EVT);
  }
  
  if ( events & SAMPLEAPP_SEND_PERIODIC_MSG_EVT1 )
  {
#if defined ( SENSOR_TERMINAL )
    //���ڼ�⿨�Ƿ����
    SampleApp_SendPeriodicMessage();
#endif
    osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SEND_PERIODIC_MSG_EVT1,
    (SAMPLEAPP_SEND_PERIODIC_MSG_TIMEOUT + (osal_rand() & 0x00FF)) );

    return (events ^ SAMPLEAPP_SEND_PERIODIC_MSG_EVT1);
  }
  

  return ( 0 );  // Discard unknown events.
}

void PrintfRfidCard(uint8* data, int len)
{
    char card_buff[20]={0};
    char error=0;

    if(data[0]==0x44 && data[1]==0x00)
    {
        HalUARTWrite (0, (uint8 *)"Mifare_UltraLight", strlen("Mifare_UltraLight"));
    }
    else if(data[0]==0x04 && data[1]==0x00)
    {
        HalUARTWrite (0, (uint8 *)"Mifare_One(S50)", strlen("Mifare_One(S50)"));
    }
    else if(data[0]==0x02 && data[1]==0x00)
    {
        HalUARTWrite (0, (uint8 *)"Mifare_One(S70)", strlen("Mifare_One(S70)"));
    }
    else if(data[0]==0x08 && data[1]==0x00)
    {
        HalUARTWrite (0, (uint8 *)"Mifare_One(X)", strlen("Mifare_One(X)"));
    }
    else if(data[0]==0x44 && data[1]==0x03)
    {
        HalUARTWrite (0, (uint8 *)"Mifare_DESFire", strlen("Mifare_DESFire"));
    }
    else
    {
        error=1;
        HalUARTWrite (0, (uint8 *)"find error", strlen("find error"));
    }


    if(error!=1)
    {
        card_buff[0]='I';
        card_buff[1]='D';
        card_buff[2]=':';
        for(int i=0; i<4; i++)
        {
            unsigned char temp= data[2+i];
            card_buff[3+i*2]=NumberToLetter((temp>>4)&0x0f);
            card_buff[3+i*2+1]=NumberToLetter(temp&0x0f);
        }

        HalLcdWriteString( card_buff, HAL_LCD_LINE_4 );
        HalUARTWrite (0, (uint8 *)card_buff, strlen(card_buff));
    }

}

void SampleApp_Device2Ctl(uint8 id, uint8 led,uint8 cmd)
{
  uint8 str[3]={id,led,cmd};
  afAddrType_t SampleApp_TxAddr;
  
  SampleApp_TxAddr.addrMode = (afAddrMode_t)Addr16Bit;//�㲥
  SampleApp_TxAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_TxAddr.addr.shortAddr = devAddr[1];//�ն�2�̵�ַ
  
  if ( AF_DataRequest( &SampleApp_TxAddr, &SampleApp_epDesc,
                       SAMPLEAPP_P2P_CLUSTERID,
                       3,
                       (uint8 *)str,
                       &SampleApp_MsgID,
                       0,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
  {
  }
  else
  {
  }
}


/*********************************************************************
 * @fn      SampleApp_ProcessMSGCmd
 *
 * @brief   Data message processor callback. This function processes
 *          any incoming data - probably from other devices. Based
 *          on the cluster ID, perform the intended action.
 *
 * @param   pkt - pointer to the incoming message packet
 *
 * @return  TRUE if the 'pkt' parameter is being used and will be freed later,
 *          FALSE otherwise.
 */
void SampleApp_ProcessMSGCmd( afIncomingMSGPacket_t *pkt )
{
  uint8 buff[100]={0};

  switch ( pkt->clusterId )
  {    
  // �����ն��ϴ����¶�����
#ifdef ZDO_COORDINATOR     
    case SAMPLEAPP_P2P_CLUSTERID: 
    {

        uint8 id   = pkt->cmd.Data[0];//�ն�id
        
        if(id==1)
        {
          temp1Int = pkt->cmd.Data[1]; //�ն��¶�
          hum1Int  = pkt->cmd.Data[2]; //�ն�ʪ�� 
          co2Int   = (pkt->cmd.Data[3] << 8) | pkt->cmd.Data[4];  // CO2��16λ��
          //�����ն�1���¶Ⱥ�ʪ��
          
          if(temp1Int >= 28)
          {
            P0_7=1;
            SampleApp_Device2Ctl(2,0x01,0);
            //������
          }
          else if(temp1Int <= 20)
          {
            P0_7 = 1;
            SampleApp_Device2Ctl(2,0x02,0);
          }
          else if(hum1Int >= 35 || co2Int >= 1000)
          {
            P0_7 = 1;
            SampleApp_Device2Ctl(2,0x04,0);
          }
          else
          {
            P0_7=0;//������
            SampleApp_Device2Ctl(2,0x01,1);
            SampleApp_Device2Ctl(2,0x02,1);
            SampleApp_Device2Ctl(2,0x04,1);
          }
        }
    }
    break;
    
    case SAMPLEAPP_P2P_CLUSTERID1:
    {
      uint16 shortAddr;
      uint8 *pIeeeAddr; 
      uint8 delay;
      uint8 afRxData[30]={0};
      uint8 afDataLen=0; 	
      if(pkt->cmd.DataLength==6)
      {
              char card_buff[20]={0};
              char error=0;
              
              //���ֿ��ĺ���
              //                0x4400 = Mifare_UltraLight
              //                0x0400 = Mifare_One(S50)
              //                0x0200 = Mifare_One(S70)
              //                0x0800 = Mifare_Pro(X)
              //                0x4403 = Mifare_DESFire

              if(pkt->cmd.Data[0]==0x44 && pkt->cmd.Data[1]==0x00)
              {
                  HalUARTWrite (0, (uint8 *)"Mifare_UltraLight,", strlen("Mifare_UltraLight,"));
              }
              else if(pkt->cmd.Data[0]==0x04 && pkt->cmd.Data[1]==0x00)
              {
                  HalUARTWrite (0, (uint8 *)"Mifare_One(S50),", strlen("Mifare_One(S50),"));
              }
              else if(pkt->cmd.Data[0]==0x02 && pkt->cmd.Data[1]==0x00)
              {
                  HalUARTWrite (0, (uint8 *)"Mifare_One(S70),", strlen("Mifare_One(S70),"));
              }
              else if(pkt->cmd.Data[0]==0x08 && pkt->cmd.Data[1]==0x00)
              {
                  HalUARTWrite (0, (uint8 *)"Mifare_One(X),", strlen("Mifare_One(X),"));
              }
              else if(pkt->cmd.Data[0]==0x44 && pkt->cmd.Data[1]==0x03)
              {
                  HalUARTWrite (0, (uint8 *)"Mifare_DESFire,", strlen("Mifare_DESFire,"));
              }
              else
              {
                  error=1;
                  HalUARTWrite (0, (uint8 *)"find error,", strlen("find error,"));
              }


              if(error!=1)
              {
                  card_buff[0]='I';
                  card_buff[1]='D';
                  card_buff[2]=':';
                  
                  //BCDתASC��
                  for(int i=0; i<4; i++)
                  {
                      unsigned char temp= pkt->cmd.Data[2+i];
                      card_buff[3+i*2]=NumberToLetter((temp>>4)&0x0f);
                      card_buff[3+i*2+1]=NumberToLetter(temp&0x0f);
                  }

                  //LCD��ʾ
                  HalUARTWrite (0, (uint8 *)card_buff, strlen(card_buff));
                  HalUARTWrite (0, (uint8 *)"\r\n", 2);
              }
              else
              {
                HalUARTWrite (0, (uint8 *)" \r\n", 2);
              }
      }
    } 
    break;

#else 
    case SAMPLEAPP_P2P_CLUSTERID: 
    {
      uint8 id = pkt->cmd.Data[0];//�ն�id
      if(id == 2)
      {
        uint8 state = pkt->cmd.Data[1];  //����Ҫ���Ƶ�LED��
        uint8 cmd   = pkt->cmd.Data[2];  //���տ���ָ��
        HalLedSet( state, cmd );
      }
    }
    break;
#endif
    case SERIALAPP_CONNECTREQ_CLUSTER:
    {
        uint8 addr=pkt->cmd.Data[0]-1;
        if(addr>=3) break;
        devAddr[addr]=BUILD_UINT16(pkt->cmd.Data[2],pkt->cmd.Data[1]);
    }

    default:
    break;
  }// switch }
}


/*********************************************************************
 * @fn      SampleApp_CallBack
 *
 * @brief   Send data OTA.
 *
 * @param   port - UART port.
 * @param   event - the UART port event flag.
 *
 * @return  none
 */
void SampleApp_CallBack(uint8 port, uint8 event)
{
  (void)port;

  if ((event & (HAL_UART_RX_FULL | HAL_UART_RX_ABOUT_FULL | HAL_UART_RX_TIMEOUT)) &&
#if SAMPLE_APP_LOOPBACK
      (SampleApp_TxLen < SAMPLE_APP_TX_MAX))
#else
      !SampleApp_TxLen)
#endif
  {
    SampleApp_TxLen += HalUARTRead(SAMPLE_APP_PORT, SampleApp_TxBuf+SampleApp_TxLen+1,
                                                      SAMPLE_APP_TX_MAX-SampleApp_TxLen);
  }
}

/*********************************************************************
 * @fn      SampleApp_Send_P2P_Message
 *
 * @brief   point to point.
 *
 * @param   none
 *
 * @return  none
 */
void SampleApp_Send_P2P_Message( void )
{
    uint8 str[5]={0};
    uint8 strTemp[32]={0};
    int len=0;
    unsigned long co2 = 0;
    DHT11();             //��ȡ��ʪ��
    
    str[0] = 1;//����һ��ID������Ƕ���ն˾��������ֵ
    str[1] = wendu;//�¶�
    str[2] = shidu;//ʪ��
    
    SGP30_Write();      //��SGP30���Ͷ�ȡ��������
    co2 = SGP30_Read(); //��ȡCO2Ũ��
    //I2C_Delay_ms(1000);
    str[3] = ( co2 >> 8 ) & 0xFF;
    str[4] = co2 & 0xFF;
    len=5;
    
    sprintf(strTemp, "T&H&C:%d %d %lu", str[1],str[2],co2);
    //HalLcdWriteString(strTemp, HAL_LCD_LINE_3); //LCD��ʾ
  
    HalUARTWrite(0, strTemp, osal_strlen(strTemp));           //���������ʾ��Ϣ
    HalUARTWrite(0, "\r\n",2);
  
    //���߷��͵�Э����
    if ( AF_DataRequest( &SampleApp_P2P_DstAddr, &SampleApp_epDesc,
                         SAMPLEAPP_P2P_CLUSTERID,
                         len,
                         str,
                         &SampleApp_MsgID,
                         AF_DISCV_ROUTE,
                         AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
    {
    }
    else
    {
      // Error occurred in request to send.
    }
}

void SampleApp_DeviceConnect()
{
  uint16 nwkAddr;
  uint16 parentNwkAddr;
  char buff[5] = {0};
  afAddrType_t SampleApp_TxAddr;
  
  nwkAddr = NLME_GetShortAddr();
  
  SampleApp_TxAddr.addrMode = (afAddrMode_t)Addr16Bit;
  SampleApp_TxAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_TxAddr.addr.shortAddr = 0x0;

  buff[0] = 2;//��ͬ���ն�Ҫ�޸����ֵ���ֱ���:1,2,3,4,5,6...
  buff[1] = HI_UINT16( nwkAddr );
  buff[2] = LO_UINT16( nwkAddr );



  if ( AF_DataRequest( &SampleApp_TxAddr, &SampleApp_epDesc,
                       SERIALAPP_CONNECTREQ_CLUSTER,
                       3,
                       (uint8*)buff,
                       &SampleApp_MsgID, 
                       0, 
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
  {
  }
  else
  {
    // Error occurred in request to send.
  }
}

void RFID_Init()
{
  P0DIR |= 0xF0; //P0_4��P0_5��P0_6��P0_7����Ϊ���
  P1DIR |= 0x21;//p1_0,P15���

  P0 |= 0xF0; //P0_4��P0_5��P0_6��P0_7���1
  P1 |= 0x21; //P1_0,P15����ߵ�ƽ

  P0SEL &= ~0x40;                  //����P0.6��Ϊ��ͨIO
  P0DIR &= ~0x40;                  //����P0.6Ϊ����
  
  CmdValid=0; 

  PcdReset();
  PcdAntennaOff(); 
  PcdAntennaOn();  
  M500PcdConfigISOType( 'A' );
}

void SampleApp_SendPeriodicMessage( void )
{
  uint8 SendBuf[10]={0};
  uint8 error=0;

  //Ѱ������
  RevBuffer[0]=0x02;
  RevBuffer[1]=0x26;

   // Ѱ��
  iccardcode();

  if(RevBuffer[1]==0)//Ѱ���ɹ�
  {
    //��������
    SendBuf[0]=RevBuffer[2];  //data
    SendBuf[1]=RevBuffer[3];  //data        

    //�ҵ���
    //����
    RevBuffer[0]=0x03;
    iccardcode();

    if(RevBuffer[1]==0)
    {
      //�����ɹ�
      //��¼��ID
      SendBuf[2]=RevBuffer[2];  //data
      SendBuf[3]=RevBuffer[3];  //data
      SendBuf[4]=RevBuffer[4];  //data
      SendBuf[5]=RevBuffer[5];  //data
    }
    else
    {
        error=1;
    }
  }
  else
  {
      error=1;
  }

  if(error>0)
  {
    SendBuf[0]=0;
    PrintfRfidCard(SendBuf, 6);
    //Ŀ���ַ
    if ( AF_DataRequest( &SampleApp_P2P_DstAddr, (endPointDesc_t *)&SampleApp_epDesc,
               SAMPLEAPP_P2P_CLUSTERID1,
               1,
               SendBuf,
               &SampleApp_MsgID,
               0,
               AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
    {
        // Successfully requested to be sent.
    }
    else
    {
        // Error occurred in request to send.
    }
  }
  else
  {
    //�����ʾ
    PrintfRfidCard(SendBuf, 6);

    //���͸�Э����
    if ( AF_DataRequest( &SampleApp_P2P_DstAddr, (endPointDesc_t *)&SampleApp_epDesc,
         SAMPLEAPP_P2P_CLUSTERID1,
         6,
         SendBuf,
         &SampleApp_MsgID, 
         0, 
         AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
    {
    // Successfully requested to be sent.
    }
    else
    {
    // Error occurred in request to send.
    }
  }
}

void iccardcode()
{
    unsigned char cmd;
    unsigned char status;

    cmd = RevBuffer[0];
    
    switch(cmd)
    {
    case 1:     // Halt the card     //��ֹ���Ĳ���
        status= PcdHalt();
        RevBuffer[0]=1;
        RevBuffer[1]=status;
        break;
    case 2:     // Request,Anticoll,Select,return CardType(2 bytes)+CardSerialNo(4 bytes)
            // Ѱ��������ͻ��ѡ��    ���ؿ����ͣ�2 bytes��+ ��ϵ�к�(4 bytes)
        status= PcdRequest(RevBuffer[1],&RevBuffer[2]);
        if(status!=0)
        {
            status= PcdRequest(RevBuffer[1],&RevBuffer[2]);
            if(status!=0)
            {
            RevBuffer[0]=1;	
            RevBuffer[1]=status;
            break;
            }
        }  
        RevBuffer[0]=3;	
        RevBuffer[1]=status;
        break;

    case 3:                         // ����ͻ ������ϵ�к� MLastSelectedSnr
        status = PcdAnticoll(&RevBuffer[2]);
        if(status!=0)
        {
            RevBuffer[0]=1;	
            RevBuffer[1]=status;
            break;
        }
        memcpy(MLastSelectedSnr,&RevBuffer[2],4);
        RevBuffer[0]=5;
        RevBuffer[1]=status;
        break;
    case 4:                   // ѡ�� Select Card
        status=PcdSelect(MLastSelectedSnr);
        if(status!=MI_OK)
        {
            RevBuffer[0]=1;	
            RevBuffer[1]=status;
            break;
        }
        RevBuffer[0]=3;
        RevBuffer[1]=status;
        break;
    case 5:	    // Key loading into the MF RC500's EEPROM
        status = PcdAuthState(RevBuffer[1], RevBuffer[3], DefaultKey, MLastSelectedSnr);// У�鿨����
        RevBuffer[0]=1;
        RevBuffer[1]=status;
        break;
    case 6: 
        RevBuffer[0]=1;
        RevBuffer[1]=status;
        break;
    case 7:     
        RevBuffer[0]=1;
        RevBuffer[1]=status;
        break;
    case 8:     // Read the mifare card
            // ����
        status=PcdRead(RevBuffer[1],&RevBuffer[2]);
        if(status==0)
        {RevBuffer[0]=17;}
        else
        {RevBuffer[0]=1;}
        RevBuffer[1]=status;			
        break;
    case 9:     // Write the mifare card
            // д��  ��������
        status=PcdWrite(RevBuffer[1],&RevBuffer[2]);
        RevBuffer[0]=1;
        RevBuffer[1]=status;			
        break;
    case 10:
        PcdValue(RevBuffer[1],RevBuffer[2],&RevBuffer[3]);
        RevBuffer[0]=1;	
        RevBuffer[1]=status;
        break;
    case 12:    // ��������
        PcdBakValue(RevBuffer[1], RevBuffer[2]);
        RevBuffer[0]=1;//contact
        RevBuffer[1]=0;
        break;
    }
}
